﻿using System;
using System.Windows;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using Microsoft.Practices.ServiceLocation;
using PlugInSample.Contracts;

namespace PlugIn1.ViewModel
{
    public class PartialViewModel : ViewModelBase
    {
        public PartialViewModel()
        {
        }

    }
}