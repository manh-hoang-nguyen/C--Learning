PLEASE NOTE

Because of the need for the Nuget packages to be restored, you must be online when you open these demo projects for the first time.

After the packages have been restored, you can disconnect from internet if needed.