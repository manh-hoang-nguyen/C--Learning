﻿namespace SelectableList.ViewModel
{
    public class ItemViewModel : SelectableViewModel
    {
        public string Title
        {
            get;
            set;
        }
    }
}