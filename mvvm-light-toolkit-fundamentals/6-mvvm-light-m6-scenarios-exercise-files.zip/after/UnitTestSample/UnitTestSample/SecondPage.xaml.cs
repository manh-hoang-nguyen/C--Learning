﻿namespace UnitTestSample
{
    public sealed partial class SecondPage
    {
        public SecondPage()
        {
            InitializeComponent();
        }
    }
}