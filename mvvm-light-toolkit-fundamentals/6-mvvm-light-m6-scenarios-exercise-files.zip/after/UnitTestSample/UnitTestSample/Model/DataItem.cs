﻿namespace UnitTestSample.Model
{
    public class DataItem
    {
        public string Property1
        {
            get;
            set;
        }

        public int Property2
        {
            get;
            set;
        }
    }
}