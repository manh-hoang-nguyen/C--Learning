﻿namespace PlugInSample.Contracts
{
    public class TestObject
    {
        public string Property1
        {
            get;
            set;
        }

        public int Property2
        {
            get;
            set;
        }
    }
}