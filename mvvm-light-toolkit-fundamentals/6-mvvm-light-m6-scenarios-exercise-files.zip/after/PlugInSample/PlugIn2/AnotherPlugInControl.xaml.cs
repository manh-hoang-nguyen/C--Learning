﻿namespace PlugIn2
{
    public partial class AnotherPlugInControl
    {
        public AnotherPlugInControl()
        {
            InitializeComponent();
        }
    }
}